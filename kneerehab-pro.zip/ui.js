// ui.js — UI Controller for Knee Rehab Exercise App

import { exercises, CATEGORIES, DIFFICULTIES, getFilteredExercises, getExerciseById } from './exercises.js';

export class UIController {
  constructor() {
    // Filter state
    this.categoryFilter = 'all';
    this.difficultyFilter = 'all';

    // Current exercise state
    this.currentExercise = null;
    this.isExerciseActive = false;
    this.currentReps = 0;
    this.currentSet = 1;
    this.holdTimer = null;
    this.holdTimeRemaining = 0;
    this.exerciseTimer = null;
    this.exerciseTime = 0;

    // Rep tracking state
    this._repPhase = 'start'; // 'start' -> 'peak' -> 'start'
    this._angleSmoothing = [];

    // Callbacks
    this.onStartExercise = null;  // (exercise) => {}
    this.onStopExercise = null;   // () => {}

    // Cache DOM elements
    this._cacheElements();

    // Init
    this._initFilters();
    this.renderExerciseCards();
  }

  _cacheElements() {
    // Library view elements
    this.exerciseGrid = document.getElementById('exercise-grid');
    this.filterBar = document.getElementById('filter-bar');

    // Exercise view elements
    this.exerciseView = document.getElementById('exercise-view');
    this.exerciseViewTitle = document.getElementById('exercise-view-title');
    this.exerciseInfoIcon = document.getElementById('exercise-info-icon');
    this.exerciseInfoName = document.getElementById('exercise-info-name');
    this.exerciseInfoDesc = document.getElementById('exercise-info-desc');
    this.instructionsList = document.getElementById('instructions-list');
    this.tipBox = document.getElementById('tip-text');
    this.backBtn = document.getElementById('back-btn');

    // Stats
    this.statSets = document.getElementById('stat-sets');
    this.statReps = document.getElementById('stat-reps');
    this.statHold = document.getElementById('stat-hold');

    // Camera overlay
    this.angleValue = document.getElementById('angle-value');
    this.angleTarget = document.getElementById('angle-target');
    this.angleLabel = document.getElementById('angle-label');
    this.repValue = document.getElementById('rep-value');
    this.repTotal = document.getElementById('rep-total');
    this.formFeedback = document.getElementById('form-feedback');
    this.angleDisplay = document.getElementById('angle-display');
    this.repCounter = document.getElementById('rep-counter');

    // Controls
    this.startExerciseBtn = document.getElementById('start-exercise-btn');
    this.stopExerciseBtn = document.getElementById('stop-exercise-btn');
    this.timerValue = document.getElementById('timer-value');
    this.progressFill = document.getElementById('progress-fill');
    this.progressLabel = document.getElementById('progress-label');
    this.progressValue = document.getElementById('progress-value-text');

    // Camera placeholder
    this.cameraPlaceholder = document.getElementById('camera-placeholder');
    this.startCameraBtn = document.getElementById('start-camera-btn');

    // Library section
    this.librarySection = document.getElementById('library-section');

    // Back button
    this.backBtn.addEventListener('click', () => this.closeExerciseView());
  }

  /**
   * Initialize filter buttons
   */
  _initFilters() {
    // Category filters
    const categoryGroup = document.getElementById('category-filters');
    categoryGroup.innerHTML = `
      <button class="filter-btn active" data-filter="all">All</button>
      ${Object.entries(CATEGORIES).map(([key, cat]) =>
        `<button class="filter-btn" data-filter="${key}">${cat.icon} ${cat.label}</button>`
      ).join('')}
    `;

    categoryGroup.addEventListener('click', (e) => {
      const btn = e.target.closest('.filter-btn');
      if (!btn) return;
      categoryGroup.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      this.categoryFilter = btn.dataset.filter;
      this.renderExerciseCards();
    });

    // Difficulty filters
    const difficultyGroup = document.getElementById('difficulty-filters');
    difficultyGroup.innerHTML = `
      <button class="filter-btn active" data-filter="all">All</button>
      ${Object.entries(DIFFICULTIES).map(([key, d]) =>
        `<button class="filter-btn" data-filter="${key}">${d.label}</button>`
      ).join('')}
    `;

    difficultyGroup.addEventListener('click', (e) => {
      const btn = e.target.closest('.filter-btn');
      if (!btn) return;
      difficultyGroup.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      this.difficultyFilter = btn.dataset.filter;
      this.renderExerciseCards();
    });
  }

  /**
   * Render exercise cards in the grid
   */
  renderExerciseCards() {
    const filtered = getFilteredExercises(this.categoryFilter, this.difficultyFilter);

    if (filtered.length === 0) {
      this.exerciseGrid.innerHTML = `
        <div class="no-exercises">
          <div class="no-exercises-icon">🔍</div>
          <h3>No exercises found</h3>
          <p>Try adjusting your filters to see more exercises.</p>
        </div>
      `;
      return;
    }

    this.exerciseGrid.innerHTML = filtered.map((ex, idx) => `
      <div class="exercise-card" data-exercise-id="${ex.id}" style="animation-delay: ${idx * 0.05}s; --card-accent: ${CATEGORIES[ex.category]?.color || 'var(--accent-primary)'}">
        <div class="card-header">
          <div class="card-icon">${ex.icon}</div>
          <div class="card-badges">
            <span class="badge badge-${ex.difficulty}">${DIFFICULTIES[ex.difficulty].label}</span>
            <span class="badge badge-category">${CATEGORIES[ex.category]?.label || ex.category}</span>
          </div>
        </div>
        <h3 class="card-title">${ex.name}</h3>
        <p class="card-description">${ex.description}</p>
        <div class="card-meta">
          <div class="meta-item">
            <span>🔄</span>
            <span class="meta-value">${ex.targetSets} sets</span>
          </div>
          <div class="meta-item">
            <span>💪</span>
            <span class="meta-value">${ex.targetReps} reps</span>
          </div>
          ${ex.holdSeconds > 0 ? `
            <div class="meta-item">
              <span>⏱️</span>
              <span class="meta-value">${ex.holdSeconds}s hold</span>
            </div>
          ` : ''}
        </div>
        <button class="card-start-btn" data-exercise-id="${ex.id}">
          <span>📷</span> Start with Camera
        </button>
      </div>
    `).join('');

    // Attach click events
    this.exerciseGrid.querySelectorAll('.exercise-card').forEach(card => {
      card.addEventListener('click', (e) => {
        // Don't trigger card click if the start button was clicked
        if (e.target.closest('.card-start-btn')) return;
        const id = card.dataset.exerciseId;
        this.openExerciseView(id);
      });
    });

    this.exerciseGrid.querySelectorAll('.card-start-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.dataset.exerciseId;
        this.openExerciseView(id);
      });
    });
  }

  /**
   * Open exercise view for a given exercise ID
   */
  openExerciseView(exerciseId) {
    const exercise = getExerciseById(exerciseId);
    if (!exercise) return;

    this.currentExercise = exercise;
    this.currentReps = 0;
    this.currentSet = 1;
    this._repPhase = 'start';
    this._angleSmoothing = [];

    // Update UI
    this.exerciseViewTitle.textContent = exercise.name;
    this.exerciseInfoIcon.textContent = exercise.icon;
    this.exerciseInfoName.textContent = exercise.name;
    this.exerciseInfoDesc.textContent = exercise.description;

    // Stats
    this.statSets.textContent = exercise.targetSets;
    this.statReps.textContent = exercise.targetReps;
    this.statHold.textContent = exercise.holdSeconds > 0 ? `${exercise.holdSeconds}s` : '—';

    // Instructions
    this.instructionsList.innerHTML = exercise.instructions
      .map(inst => `<li>${inst}</li>`)
      .join('');

    // Tips
    this.tipBox.textContent = exercise.tips;

    // Angle display
    this.angleLabel.textContent = exercise.targetAngle.label;
    this.angleTarget.textContent = `Target: ${exercise.targetAngle.min}° — ${exercise.targetAngle.max}°`;

    // Reset counters
    this.repValue.textContent = '0';
    this.repTotal.textContent = `/ ${exercise.targetReps}`;
    this.angleValue.textContent = '—';
    this.formFeedback.textContent = 'Position yourself in view';
    this.formFeedback.className = 'form-feedback';

    // Reset progress
    this.updateProgress(0);

    // Reset timer
    this.exerciseTime = 0;
    this.timerValue.textContent = '00:00';

    // Reset controls
    this.startExerciseBtn.innerHTML = '<span>▶️</span> Start Exercise';
    this.isExerciseActive = false;

    // Show exercise view, hide library
    this.librarySection.style.display = 'none';
    this.exerciseView.classList.add('active');

    // Trigger callback
    if (this.onStartExercise) {
      this.onStartExercise(exercise);
    }
  }

  /**
   * Close exercise view
   */
  closeExerciseView() {
    this.exerciseView.classList.remove('active');
    this.librarySection.style.display = '';
    this.isExerciseActive = false;
    this.currentExercise = null;

    // Stop timers
    this._stopTimers();

    if (this.onStopExercise) {
      this.onStopExercise();
    }
  }

  /**
   * Toggle exercise active state
   */
  toggleExercise() {
    this.isExerciseActive = !this.isExerciseActive;

    if (this.isExerciseActive) {
      this.startExerciseBtn.innerHTML = '<span>⏸️</span> Pause Exercise';
      this._startExerciseTimer();
    } else {
      this.startExerciseBtn.innerHTML = '<span>▶️</span> Resume Exercise';
      this._stopTimers();
    }
  }

  /**
   * Start the exercise timer
   */
  _startExerciseTimer() {
    this._stopTimers();
    this.exerciseTimer = setInterval(() => {
      this.exerciseTime++;
      const mins = Math.floor(this.exerciseTime / 60).toString().padStart(2, '0');
      const secs = (this.exerciseTime % 60).toString().padStart(2, '0');
      this.timerValue.textContent = `${mins}:${secs}`;
    }, 1000);
  }

  _stopTimers() {
    if (this.exerciseTimer) {
      clearInterval(this.exerciseTimer);
      this.exerciseTimer = null;
    }
    if (this.holdTimer) {
      clearInterval(this.holdTimer);
      this.holdTimer = null;
    }
  }

  /**
   * Update pose data from the engine
   */
  updatePoseData(landmarks, worldLandmarks, PoseEngine) {
    if (!this.currentExercise || !this.isExerciseActive) return;

    const exercise = this.currentExercise;
    let angle = null;

    // Calculate the relevant angle based on the exercise's primary joint
    if (exercise.primaryJoint === 'knee') {
      const leftAngle = PoseEngine.getKneeAngle(landmarks, 'left');
      const rightAngle = PoseEngine.getKneeAngle(landmarks, 'right');
      // Use the average of visible angles, or whichever is available
      if (leftAngle !== null && rightAngle !== null) {
        angle = (leftAngle + rightAngle) / 2;
      } else {
        angle = leftAngle ?? rightAngle;
      }
    } else if (exercise.primaryJoint === 'hip') {
      const leftAngle = PoseEngine.getHipAngle(landmarks, 'left');
      const rightAngle = PoseEngine.getHipAngle(landmarks, 'right');
      if (leftAngle !== null && rightAngle !== null) {
        angle = (leftAngle + rightAngle) / 2;
      } else {
        angle = leftAngle ?? rightAngle;
      }
    } else if (exercise.primaryJoint === 'ankle') {
      // For ankle pumps, track knee angle as a proxy
      const leftAngle = PoseEngine.getKneeAngle(landmarks, 'left');
      const rightAngle = PoseEngine.getKneeAngle(landmarks, 'right');
      angle = leftAngle ?? rightAngle;
    }

    if (angle !== null) {
      // Smooth the angle
      this._angleSmoothing.push(angle);
      if (this._angleSmoothing.length > 5) {
        this._angleSmoothing.shift();
      }
      const smoothedAngle = this._angleSmoothing.reduce((a, b) => a + b, 0) / this._angleSmoothing.length;

      // Update angle display
      this.angleValue.textContent = `${Math.round(smoothedAngle)}°`;

      // Evaluate form
      const form = PoseEngine.evaluateForm(smoothedAngle, exercise.targetAngle.min, exercise.targetAngle.max);
      this._updateFormFeedback(form, smoothedAngle);

      // Track reps
      this._trackReps(smoothedAngle);
    }
  }

  /**
   * Update form feedback display
   */
  _updateFormFeedback(form, angle) {
    const exercise = this.currentExercise;

    switch (form) {
      case 'good':
        this.formFeedback.textContent = '✅ Great form! Hold this position';
        this.formFeedback.className = 'form-feedback good';
        this.angleValue.className = 'angle-value';
        break;
      case 'close':
        if (angle < exercise.targetAngle.min) {
          this.formFeedback.textContent = '↕️ Adjust slightly — bend a bit more';
        } else {
          this.formFeedback.textContent = '↕️ Adjust slightly — straighten a bit more';
        }
        this.formFeedback.className = 'form-feedback adjust';
        this.angleValue.className = 'angle-value warning';
        break;
      case 'adjust':
        if (angle < exercise.targetAngle.min) {
          this.formFeedback.textContent = '⚠️ Bend your knee more toward target range';
        } else {
          this.formFeedback.textContent = '⚠️ Straighten your leg toward target range';
        }
        this.formFeedback.className = 'form-feedback bad';
        this.angleValue.className = 'angle-value warning';
        break;
      default:
        this.formFeedback.textContent = 'Position your body in the camera view';
        this.formFeedback.className = 'form-feedback';
    }
  }

  /**
   * Track rep completion based on angle changes
   */
  _trackReps(angle) {
    const exercise = this.currentExercise;
    const targetMin = exercise.targetAngle.min;
    const targetMax = exercise.targetAngle.max;
    const midPoint = (targetMin + targetMax) / 2;

    // Simple state machine for rep detection
    // Phase 'start': waiting for the angle to enter target range
    // Phase 'peak': angle is in target range, waiting for exit
    if (this._repPhase === 'start') {
      if (angle >= targetMin && angle <= targetMax) {
        this._repPhase = 'peak';
      }
    } else if (this._repPhase === 'peak') {
      // Check if the angle has exited the target range significantly
      const exitThreshold = 20; // degrees outside the range
      if (angle < targetMin - exitThreshold || angle > targetMax + exitThreshold) {
        this.currentReps++;
        this._repPhase = 'start';
        this.repValue.textContent = this.currentReps.toString();

        // Check if set is complete
        if (this.currentReps >= exercise.targetReps) {
          if (this.currentSet < exercise.targetSets) {
            this.currentSet++;
            this.currentReps = 0;
            this.repValue.textContent = '0';
            this.formFeedback.textContent = `🎉 Set ${this.currentSet - 1} complete! Starting set ${this.currentSet}`;
            this.formFeedback.className = 'form-feedback good';
          } else {
            this.formFeedback.textContent = '🏆 All sets complete! Great job!';
            this.formFeedback.className = 'form-feedback good';
            this.isExerciseActive = false;
            this.startExerciseBtn.innerHTML = '<span>🔄</span> Restart Exercise';
          }
        }

        // Update progress
        const totalReps = exercise.targetSets * exercise.targetReps;
        const completedReps = (this.currentSet - 1) * exercise.targetReps + this.currentReps;
        this.updateProgress(completedReps / totalReps);
      }
    }
  }

  /**
   * Update progress bar
   */
  updateProgress(fraction) {
    const pct = Math.min(100, Math.round(fraction * 100));
    this.progressFill.style.width = `${pct}%`;
    this.progressValue.textContent = `${pct}%`;

    if (this.currentExercise) {
      this.progressLabel.textContent = `Set ${this.currentSet} of ${this.currentExercise.targetSets}`;
    }
  }

  /**
   * Show/hide camera placeholder
   */
  showCameraPlaceholder(show) {
    this.cameraPlaceholder.style.display = show ? 'flex' : 'none';
  }

  /**
   * Hide loading screen
   */
  hideLoading() {
    const loading = document.getElementById('loading-screen');
    if (loading) {
      loading.classList.add('hidden');
      setTimeout(() => loading.remove(), 500);
    }
  }

  /**
   * Update loading text
   */
  setLoadingText(text) {
    const el = document.getElementById('loading-text');
    if (el) el.textContent = text;
  }
}
