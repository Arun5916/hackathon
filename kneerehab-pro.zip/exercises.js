// exercises.js — Knee Surgery Rehabilitation Exercise Library

export const CATEGORIES = {
  'range-of-motion': { label: 'Range of Motion', icon: '🔄', color: '#06d6a0' },
  'strengthening': { label: 'Strengthening', icon: '💪', color: '#118ab2' },
  'balance': { label: 'Balance & Stability', icon: '⚖️', color: '#ffd166' }
};

export const DIFFICULTIES = {
  'beginner': { label: 'Beginner', color: '#06d6a0', order: 1 },
  'intermediate': { label: 'Intermediate', color: '#ffd166', order: 2 },
  'advanced': { label: 'Advanced', color: '#ef476f', order: 3 }
};

export const exercises = [
  {
    id: 'quad-sets',
    name: 'Quad Sets',
    icon: '🦵',
    category: 'range-of-motion',
    difficulty: 'beginner',
    description: 'Tighten your thigh muscle and press the back of your knee flat against the surface. This foundational exercise helps restore quadriceps activation after surgery.',
    instructions: [
      'Sit or lie down with your operated leg extended straight',
      'Tighten the muscle on top of your thigh (quadriceps)',
      'Press the back of your knee firmly into the floor or bed',
      'Hold the contraction for 5 seconds',
      'Slowly relax and repeat'
    ],
    targetSets: 3,
    targetReps: 10,
    holdSeconds: 5,
    targetAngle: { min: 165, max: 180, label: 'Knee Extension' },
    primaryJoint: 'knee',
    landmarks: {
      left: { hip: 23, knee: 25, ankle: 27 },
      right: { hip: 24, knee: 26, ankle: 28 }
    },
    tips: 'Focus on feeling tightness in the front of your thigh. Your kneecap should shift slightly upward when contracting correctly.',
    weekPostSurgery: 1
  },
  {
    id: 'straight-leg-raises',
    name: 'Straight Leg Raises',
    icon: '🦿',
    category: 'strengthening',
    difficulty: 'beginner',
    description: 'Strengthen your quadriceps by lifting your straight leg off the surface. Essential for rebuilding thigh strength after knee surgery.',
    instructions: [
      'Lie on your back with your non-operated knee bent, foot flat',
      'Keep your operated leg straight with toes pointed up',
      'Tighten your thigh muscle (quad set first)',
      'Slowly lift your leg about 12 inches off the surface',
      'Hold for 3 seconds, then slowly lower back down'
    ],
    targetSets: 3,
    targetReps: 10,
    holdSeconds: 3,
    targetAngle: { min: 140, max: 170, label: 'Hip Flexion' },
    primaryJoint: 'hip',
    landmarks: {
      left: { shoulder: 11, hip: 23, knee: 25 },
      right: { shoulder: 12, hip: 24, knee: 26 }
    },
    tips: 'Keep your leg completely straight while lifting. If your knee bends, lower the height of the lift.',
    weekPostSurgery: 1
  },
  {
    id: 'heel-slides',
    name: 'Heel Slides',
    icon: '🦶',
    category: 'range-of-motion',
    difficulty: 'beginner',
    description: 'Gently bend your knee by sliding your heel toward your buttocks. Crucial for regaining knee flexion range of motion.',
    instructions: [
      'Lie on your back with both legs extended',
      'Slowly slide your heel along the surface toward your buttocks',
      'Bend your knee as far as comfortable',
      'Hold the bent position for 2 seconds',
      'Slowly slide your heel back to the starting position'
    ],
    targetSets: 3,
    targetReps: 10,
    holdSeconds: 2,
    targetAngle: { min: 70, max: 120, label: 'Knee Flexion' },
    primaryJoint: 'knee',
    landmarks: {
      left: { hip: 23, knee: 25, ankle: 27 },
      right: { hip: 24, knee: 26, ankle: 28 }
    },
    tips: 'Use a towel under your heel to reduce friction. Go only as far as pain allows — do not force the bend.',
    weekPostSurgery: 1
  },
  {
    id: 'ankle-pumps',
    name: 'Ankle Pumps',
    icon: '🔄',
    category: 'range-of-motion',
    difficulty: 'beginner',
    description: 'Flex and point your foot to promote blood circulation and reduce swelling. One of the first exercises after surgery.',
    instructions: [
      'Sit or lie down with your leg extended',
      'Slowly point your toes away from you (plantar flexion)',
      'Hold for 2 seconds',
      'Pull your toes back toward you (dorsiflexion)',
      'Hold for 2 seconds and repeat rhythmically'
    ],
    targetSets: 3,
    targetReps: 20,
    holdSeconds: 2,
    targetAngle: { min: 90, max: 180, label: 'Ankle Range' },
    primaryJoint: 'ankle',
    landmarks: {
      left: { knee: 25, ankle: 27, foot: 31 },
      right: { knee: 26, ankle: 28, foot: 32 }
    },
    tips: 'Perform this exercise every hour while awake to help prevent blood clots and reduce swelling.',
    weekPostSurgery: 0
  },
  {
    id: 'seated-knee-extension',
    name: 'Seated Knee Extension',
    icon: '🪑',
    category: 'strengthening',
    difficulty: 'beginner',
    description: 'Extend your knee from a seated position to strengthen the quadriceps. Controlled movement builds strength progressively.',
    instructions: [
      'Sit upright in a sturdy chair with feet flat on the floor',
      'Slowly straighten your operated knee, lifting your foot',
      'Extend until your leg is as straight as possible',
      'Hold for 3 seconds at the top',
      'Slowly lower your foot back to the floor'
    ],
    targetSets: 3,
    targetReps: 10,
    holdSeconds: 3,
    targetAngle: { min: 160, max: 180, label: 'Knee Extension' },
    primaryJoint: 'knee',
    landmarks: {
      left: { hip: 23, knee: 25, ankle: 27 },
      right: { hip: 24, knee: 26, ankle: 28 }
    },
    tips: 'Sit tall — avoid leaning back. Control the movement in both directions; don\'t let gravity drop your leg.',
    weekPostSurgery: 2
  },
  {
    id: 'standing-knee-bends',
    name: 'Standing Knee Bends',
    icon: '🏋️',
    category: 'strengthening',
    difficulty: 'intermediate',
    description: 'Perform controlled mini-squats to build functional strength. Use a counter or chair for balance support.',
    instructions: [
      'Stand with feet shoulder-width apart, holding a counter for support',
      'Slowly bend both knees as if sitting back into a chair',
      'Lower yourself about 6-8 inches (mini squat)',
      'Keep your weight on your heels, knees behind toes',
      'Slowly straighten back to standing'
    ],
    targetSets: 3,
    targetReps: 10,
    holdSeconds: 0,
    targetAngle: { min: 110, max: 150, label: 'Knee Flexion' },
    primaryJoint: 'knee',
    landmarks: {
      left: { hip: 23, knee: 25, ankle: 27 },
      right: { hip: 24, knee: 26, ankle: 28 }
    },
    tips: 'Start shallow and gradually increase depth as strength improves. Never bend past 90 degrees in early recovery.',
    weekPostSurgery: 4
  },
  {
    id: 'wall-squats',
    name: 'Wall Squats',
    icon: '🧱',
    category: 'strengthening',
    difficulty: 'intermediate',
    description: 'Lean against a wall and slide down into a partial squat. The wall provides support and helps maintain proper form.',
    instructions: [
      'Stand with your back flat against a smooth wall',
      'Place feet about 12 inches from the wall, shoulder-width apart',
      'Slowly slide your back down the wall, bending your knees',
      'Stop when knees are at about 45 degrees',
      'Hold for 5-10 seconds, then slowly slide back up'
    ],
    targetSets: 3,
    targetReps: 8,
    holdSeconds: 10,
    targetAngle: { min: 120, max: 160, label: 'Knee Flexion' },
    primaryJoint: 'knee',
    landmarks: {
      left: { hip: 23, knee: 25, ankle: 27 },
      right: { hip: 24, knee: 26, ankle: 28 }
    },
    tips: 'Keep your knees aligned over your ankles — don\'t let them drift forward past your toes.',
    weekPostSurgery: 4
  },
  {
    id: 'hamstring-curls',
    name: 'Standing Hamstring Curls',
    icon: '🔁',
    category: 'strengthening',
    difficulty: 'intermediate',
    description: 'Curl your heel toward your buttocks while standing. Builds hamstring strength essential for knee stability.',
    instructions: [
      'Stand holding a counter or chair for balance',
      'Shift your weight to your non-operated leg',
      'Slowly bend your operated knee, bringing your heel toward your buttocks',
      'Bend as far as comfortable (aim for 90 degrees)',
      'Slowly lower your foot back to the floor'
    ],
    targetSets: 3,
    targetReps: 10,
    holdSeconds: 2,
    targetAngle: { min: 80, max: 120, label: 'Knee Flexion' },
    primaryJoint: 'knee',
    landmarks: {
      left: { hip: 23, knee: 25, ankle: 27 },
      right: { hip: 24, knee: 26, ankle: 28 }
    },
    tips: 'Keep your thighs parallel — don\'t lift your knee forward. Only your lower leg should move.',
    weekPostSurgery: 3
  },
  {
    id: 'step-ups',
    name: 'Step-Ups',
    icon: '🪜',
    category: 'balance',
    difficulty: 'advanced',
    description: 'Step up onto a low platform with your operated leg leading. Builds functional strength for stairs and daily activities.',
    instructions: [
      'Stand in front of a 4-6 inch step or platform',
      'Place your operated foot firmly on the step',
      'Press through your heel to step up, straightening your knee',
      'Bring your other foot up to meet the first',
      'Step back down slowly, leading with the non-operated leg'
    ],
    targetSets: 3,
    targetReps: 8,
    holdSeconds: 0,
    targetAngle: { min: 100, max: 170, label: 'Knee Flexion/Extension' },
    primaryJoint: 'knee',
    landmarks: {
      left: { hip: 23, knee: 25, ankle: 27 },
      right: { hip: 24, knee: 26, ankle: 28 }
    },
    tips: 'Start with a low step (4 inches). Use a railing for balance. Focus on controlled, deliberate movements.',
    weekPostSurgery: 6
  },
  {
    id: 'single-leg-balance',
    name: 'Single Leg Balance',
    icon: '🧘',
    category: 'balance',
    difficulty: 'advanced',
    description: 'Stand on your operated leg to improve proprioception and balance. Critical for safe walking and fall prevention.',
    instructions: [
      'Stand near a counter or wall for safety',
      'Shift your weight onto your operated leg',
      'Slowly lift your non-operated foot off the floor',
      'Balance on one leg for up to 30 seconds',
      'Use the counter for support if you feel unsteady'
    ],
    targetSets: 3,
    targetReps: 5,
    holdSeconds: 30,
    targetAngle: { min: 165, max: 180, label: 'Knee Extension' },
    primaryJoint: 'knee',
    landmarks: {
      left: { hip: 23, knee: 25, ankle: 27 },
      right: { hip: 24, knee: 26, ankle: 28 }
    },
    tips: 'Start with light finger-touch support on the counter. Progress to no support as confidence grows.',
    weekPostSurgery: 6
  }
];

/**
 * Get exercises filtered by category and/or difficulty
 */
export function getFilteredExercises(categoryFilter = 'all', difficultyFilter = 'all') {
  return exercises.filter(ex => {
    const categoryMatch = categoryFilter === 'all' || ex.category === categoryFilter;
    const difficultyMatch = difficultyFilter === 'all' || ex.difficulty === difficultyFilter;
    return categoryMatch && difficultyMatch;
  });
}

/**
 * Get a single exercise by its ID
 */
export function getExerciseById(id) {
  return exercises.find(ex => ex.id === id);
}
